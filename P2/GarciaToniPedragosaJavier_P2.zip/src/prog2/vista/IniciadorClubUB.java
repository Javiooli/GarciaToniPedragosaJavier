/*
 * Universitat de Barcelona
 * Programació 2
 * Curs 2021-2022
 */
package prog2.vista;

public class IniciadorClubUB {
    public static void main(String [] args) {
        VistaClubUB vistaClub = new VistaClubUB("ClubUB", 100);
        vistaClub.gestioClubUB();
    }
}
