package prog2.vista;

public final class IniciadorMercatUB {
    public static void main(String[] args) {
        MercatUB vistaMercat = new MercatUB();
        vistaMercat.gestioMercatUB();
    }
}
