package prog2.vista;

public class MercatException extends Exception {
    
    public MercatException() {
        super();
    }

    public MercatException(String msg) {
        super(msg);
    }

}
